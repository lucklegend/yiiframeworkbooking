<?php

return array (
  0 => 
  array (
    'id' => 1,
    'tree' => 1,
    'lft' => 1,
    'rgt' => 44,
    'depth' => 0,
    'name' => 'Root 1',
  ),
  1 => 
  array (
    'id' => 23,
    'tree' => 23,
    'lft' => 1,
    'rgt' => 44,
    'depth' => 0,
    'name' => 'Root 2',
  ),
  2 => 
  array (
    'id' => 45,
    'tree' => 45,
    'lft' => 1,
    'rgt' => 44,
    'depth' => 0,
    'name' => 'Root 3',
  ),
);