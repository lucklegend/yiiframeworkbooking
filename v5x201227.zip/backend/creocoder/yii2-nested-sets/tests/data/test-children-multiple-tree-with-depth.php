<?php

return array (
  0 => 
  array (
    'id' => 32,
    'tree' => 23,
    'lft' => 17,
    'rgt' => 22,
    'depth' => 2,
    'name' => 'Node 2.1',
  ),
  1 => 
  array (
    'id' => 35,
    'tree' => 23,
    'lft' => 23,
    'rgt' => 28,
    'depth' => 2,
    'name' => 'Node 2.2',
  ),
);