<?php

return array (
  0 => 
  array (
    'id' => 24,
    'tree' => 23,
    'lft' => 2,
    'rgt' => 15,
    'depth' => 1,
    'name' => 'Node 1',
  ),
);