<?php

return array (
  0 => 
  array (
    'id' => 10,
    'lft' => 17,
    'rgt' => 22,
    'depth' => 2,
    'name' => 'Node 2.1',
  ),
);