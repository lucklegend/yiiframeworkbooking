<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "userful".
 *
 * @property integer $id
 * @property string $name
 * @property string $service
 * @property string $address
 * @property string $tel
 * @property string $status
 */
class Userful extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'userful';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['status', 'name','service'], 'required'],
            [['status'], 'string'],
            [['name', 'address','service' ,'tel'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'service' => 'Service',
            'address' => 'Address',
            'tel' => 'Tel',
            'status' => 'Status',
        ];
    }
}
