<?php

$baseUrl = 'http://' . $_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
$baseUrl = str_replace('/backend', '',$baseUrl);
define('BACKEND', $baseUrl.'/backend');
define('FRONTEND', $baseUrl);

define('filepath', $baseUrl.'/statics/web/pages/files');
Yii::setAlias('@test',$baseUrl);

return [];

