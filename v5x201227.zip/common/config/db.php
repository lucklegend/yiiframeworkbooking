<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=127.0.0.1;dbname=facility_v5ardmorepark',
    'username' => 'facility_v5ardmorepark',
    'password' => 'K4ICd4csGxzu',
    'charset' => 'utf8',
    'tablePrefix' => ''
];
