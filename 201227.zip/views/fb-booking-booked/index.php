<?php

use yii\helpers\Html;
//use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\helpers\ArrayHelper;

use vova07\themes\admin\widgets\Box;
use yii\grid\CheckboxColumn;
use common\models\FbBookingFacility;
use common\models\FbBookingStatus;
use kartik\grid\GridView;
use kartik\export\ExportMenu;
use kartik\tabs\TabsX;

/* @var $this yii\web\View */
/* @var $searchModel common\models\FbBookingBookedSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Facility Booking';
$this->params['subtitle'] = 'Booked list';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
.h3.visible-print-block{
	display: none !important;
}
</style>
<div class="fb-booking-booked-index">
 
		    <div class="page-title">
                <h2> Bookings </h2>
                <span class="line-h"></span> 
            </div>

            <?php
            $items = [
                [
                    'label'=>'<i class="fa fa-ticket"></i> Past Bookings',                      
                    'linkOptions'=>['data-url'=>\yii\helpers\Url::to(['/fb-booking-booked/old'])],                    
                    'active'=>true,
                ],
                [
                    'label'=>'<i class="fa fa-ticket"></i> current + future Bookings',                     
                    'linkOptions'=>['data-url'=>\yii\helpers\Url::to(['/fb-booking-booked/curr'])]
                ],
                
            ]; 

            echo TabsX::widget([
                 

                'items'=>$items,
                'position'=>TabsX::POS_ABOVE, 
                'height'=>TabsX::SIZE_LARGE,
                'bordered'=>true,
                'encodeLabels'=>false
            ]);

            $this->registerJs('
            $("document").ready(function() {
            setTimeout(function() {
            $(".tabs-krajee").find("li.active a").click();
            },10);
            });', \yii\web\View::POS_READY);
            ?> 
       