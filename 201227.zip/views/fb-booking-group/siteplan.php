<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use vova07\themes\admin\widgets\Box;
use yii\grid\CheckboxColumn;


/* @var $this yii\web\View */
/* @var $searchModel app\models\FbBookingFacilitySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Site Plan';
?>
<div class="fb-booking-facility-index">
	<h1>Site Plan</h1>
	<div>
		<!-- <div>
			<center> -->
				<img src="statics/web/siteplan1.jpg"  border="0" usemap="#fac2" class="img-responsive" style="margin-top:10px;" />
			<!-- </center>
		</div> -->
	</div>
	
</div>
