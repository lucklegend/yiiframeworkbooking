<?php

return array (
  0 => 
  array (
    'id' => 1,
    'lft' => 1,
    'rgt' => 44,
    'depth' => 0,
    'name' => 'Root',
  ),
  1 => 
  array (
    'id' => 9,
    'lft' => 16,
    'rgt' => 29,
    'depth' => 1,
    'name' => 'Node 2',
  ),
  2 => 
  array (
    'id' => 10,
    'lft' => 17,
    'rgt' => 22,
    'depth' => 2,
    'name' => 'Node 2.1',
  ),
);