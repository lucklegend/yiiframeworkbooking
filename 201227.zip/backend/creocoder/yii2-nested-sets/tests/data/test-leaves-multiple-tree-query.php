<?php

return array (
  0 => 
  array (
    'id' => 4,
    'tree' => 1,
    'lft' => 4,
    'rgt' => 5,
    'depth' => 3,
    'name' => 'Node 1.1.1',
  ),
  1 => 
  array (
    'id' => 5,
    'tree' => 1,
    'lft' => 6,
    'rgt' => 7,
    'depth' => 3,
    'name' => 'Node 1.1.2',
  ),
  2 => 
  array (
    'id' => 7,
    'tree' => 1,
    'lft' => 10,
    'rgt' => 11,
    'depth' => 3,
    'name' => 'Node 1.2.1',
  ),
  3 => 
  array (
    'id' => 8,
    'tree' => 1,
    'lft' => 12,
    'rgt' => 13,
    'depth' => 3,
    'name' => 'Node 1.2.2',
  ),
  4 => 
  array (
    'id' => 11,
    'tree' => 1,
    'lft' => 18,
    'rgt' => 19,
    'depth' => 3,
    'name' => 'Node 2.1.1',
  ),
  5 => 
  array (
    'id' => 12,
    'tree' => 1,
    'lft' => 20,
    'rgt' => 21,
    'depth' => 3,
    'name' => 'Node 2.1.2',
  ),
  6 => 
  array (
    'id' => 14,
    'tree' => 1,
    'lft' => 24,
    'rgt' => 25,
    'depth' => 3,
    'name' => 'Node 2.2.1',
  ),
  7 => 
  array (
    'id' => 15,
    'tree' => 1,
    'lft' => 26,
    'rgt' => 27,
    'depth' => 3,
    'name' => 'Node 2.2.2',
  ),
  8 => 
  array (
    'id' => 18,
    'tree' => 1,
    'lft' => 32,
    'rgt' => 33,
    'depth' => 3,
    'name' => 'Node 3.1.1',
  ),
  9 => 
  array (
    'id' => 19,
    'tree' => 1,
    'lft' => 34,
    'rgt' => 35,
    'depth' => 3,
    'name' => 'Node 3.1.2',
  ),
  10 => 
  array (
    'id' => 21,
    'tree' => 1,
    'lft' => 38,
    'rgt' => 39,
    'depth' => 3,
    'name' => 'Node 3.2.1',
  ),
  11 => 
  array (
    'id' => 22,
    'tree' => 1,
    'lft' => 40,
    'rgt' => 41,
    'depth' => 3,
    'name' => 'Node 3.2.2',
  ),
  12 => 
  array (
    'id' => 26,
    'tree' => 23,
    'lft' => 4,
    'rgt' => 5,
    'depth' => 3,
    'name' => 'Node 1.1.1',
  ),
  13 => 
  array (
    'id' => 27,
    'tree' => 23,
    'lft' => 6,
    'rgt' => 7,
    'depth' => 3,
    'name' => 'Node 1.1.2',
  ),
  14 => 
  array (
    'id' => 29,
    'tree' => 23,
    'lft' => 10,
    'rgt' => 11,
    'depth' => 3,
    'name' => 'Node 1.2.1',
  ),
  15 => 
  array (
    'id' => 30,
    'tree' => 23,
    'lft' => 12,
    'rgt' => 13,
    'depth' => 3,
    'name' => 'Node 1.2.2',
  ),
  16 => 
  array (
    'id' => 33,
    'tree' => 23,
    'lft' => 18,
    'rgt' => 19,
    'depth' => 3,
    'name' => 'Node 2.1.1',
  ),
  17 => 
  array (
    'id' => 34,
    'tree' => 23,
    'lft' => 20,
    'rgt' => 21,
    'depth' => 3,
    'name' => 'Node 2.1.2',
  ),
  18 => 
  array (
    'id' => 36,
    'tree' => 23,
    'lft' => 24,
    'rgt' => 25,
    'depth' => 3,
    'name' => 'Node 2.2.1',
  ),
  19 => 
  array (
    'id' => 37,
    'tree' => 23,
    'lft' => 26,
    'rgt' => 27,
    'depth' => 3,
    'name' => 'Node 2.2.2',
  ),
  20 => 
  array (
    'id' => 40,
    'tree' => 23,
    'lft' => 32,
    'rgt' => 33,
    'depth' => 3,
    'name' => 'Node 3.1.1',
  ),
  21 => 
  array (
    'id' => 41,
    'tree' => 23,
    'lft' => 34,
    'rgt' => 35,
    'depth' => 3,
    'name' => 'Node 3.1.2',
  ),
  22 => 
  array (
    'id' => 43,
    'tree' => 23,
    'lft' => 38,
    'rgt' => 39,
    'depth' => 3,
    'name' => 'Node 3.2.1',
  ),
  23 => 
  array (
    'id' => 44,
    'tree' => 23,
    'lft' => 40,
    'rgt' => 41,
    'depth' => 3,
    'name' => 'Node 3.2.2',
  ),
  24 => 
  array (
    'id' => 48,
    'tree' => 45,
    'lft' => 4,
    'rgt' => 5,
    'depth' => 3,
    'name' => 'Node 1.1.1',
  ),
  25 => 
  array (
    'id' => 49,
    'tree' => 45,
    'lft' => 6,
    'rgt' => 7,
    'depth' => 3,
    'name' => 'Node 1.1.2',
  ),
  26 => 
  array (
    'id' => 51,
    'tree' => 45,
    'lft' => 10,
    'rgt' => 11,
    'depth' => 3,
    'name' => 'Node 1.2.1',
  ),
  27 => 
  array (
    'id' => 52,
    'tree' => 45,
    'lft' => 12,
    'rgt' => 13,
    'depth' => 3,
    'name' => 'Node 1.2.2',
  ),
  28 => 
  array (
    'id' => 55,
    'tree' => 45,
    'lft' => 18,
    'rgt' => 19,
    'depth' => 3,
    'name' => 'Node 2.1.1',
  ),
  29 => 
  array (
    'id' => 56,
    'tree' => 45,
    'lft' => 20,
    'rgt' => 21,
    'depth' => 3,
    'name' => 'Node 2.1.2',
  ),
  30 => 
  array (
    'id' => 58,
    'tree' => 45,
    'lft' => 24,
    'rgt' => 25,
    'depth' => 3,
    'name' => 'Node 2.2.1',
  ),
  31 => 
  array (
    'id' => 59,
    'tree' => 45,
    'lft' => 26,
    'rgt' => 27,
    'depth' => 3,
    'name' => 'Node 2.2.2',
  ),
  32 => 
  array (
    'id' => 62,
    'tree' => 45,
    'lft' => 32,
    'rgt' => 33,
    'depth' => 3,
    'name' => 'Node 3.1.1',
  ),
  33 => 
  array (
    'id' => 63,
    'tree' => 45,
    'lft' => 34,
    'rgt' => 35,
    'depth' => 3,
    'name' => 'Node 3.1.2',
  ),
  34 => 
  array (
    'id' => 65,
    'tree' => 45,
    'lft' => 38,
    'rgt' => 39,
    'depth' => 3,
    'name' => 'Node 3.2.1',
  ),
  35 => 
  array (
    'id' => 66,
    'tree' => 45,
    'lft' => 40,
    'rgt' => 41,
    'depth' => 3,
    'name' => 'Node 3.2.2',
  ),
);